import cli.UI;

public class Main {

    public static void main(String[] args) {
    	
    	new UI();
    }
}
